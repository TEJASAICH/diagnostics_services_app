# Diagnostic Services App

A comprehensive web application for managing diagnostic laboratory services, including patient registration, test management, billing, and reporting.

## Features

- **Patient Management**
  - Register new patients
  - View and update patient records
  - Track patient history

- **Laboratory Operations**
  - Test result entry
  - View and manage test reports
  - Generate referral reports

- **Billing System**
  - Generate bills for tests
  - Apply discounts
  - View billing history

- **Role-Based Access**
  - Reception Dashboard
  - Laboratory Dashboard
  - Separate interfaces for different staff roles

## Tech Stack

- **Backend**
  - Flask (Python web framework)
  - MySQL Database
  - Python-dotenv for environment management

- **Frontend**
  - HTML5
  - Bootstrap 5.3.3
  - Chart.js for data visualization
  - Font Awesome icons

## Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/DiagnosticServicesApp.git
cd DiagnosticServicesApp