CREATE DATABASE IF NOT EXISTS diagnostic_db;
USE diagnostic_db;

CREATE TABLE patient (
    patient_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    age INT,
    gender VARCHAR(10),
    contact VARCHAR(15),
    address TEXT,
    medical_history TEXT
);
