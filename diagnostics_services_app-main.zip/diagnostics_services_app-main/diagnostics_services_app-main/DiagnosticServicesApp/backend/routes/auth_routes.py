from flask import Blueprint, request, jsonify
from backend.db import get_db_connection

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.json
    username = data.get("username")
    password = data.get("password")

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
    user = cursor.fetchone()
    cursor.close()
    conn.close()

    if user:
        return jsonify({
            "message": "Login successful!",
            "user": {
                "name": user["name"],
                "role": user["role"]
            }
        })
    else:
        return jsonify({"message": "Invalid username or password"}), 401
