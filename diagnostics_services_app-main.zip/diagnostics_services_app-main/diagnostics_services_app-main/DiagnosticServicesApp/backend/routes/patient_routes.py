from flask import Blueprint, request, jsonify
from backend.db import get_db_connection

patient_bp = Blueprint('patient', __name__)

@patient_bp.route('/register', methods=['POST'])
def register_patient():
    data = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO patients (full_name, gender, mobile, email, age, weight, city, pincode, referred_by)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
    """, (
        data['full_name'],
        data['gender'],
        data['mobile'],
        data['email'],
        data['age'],
        data['weight'],
        data['city'],
        data['pincode'],
        data['referred_by']
    ))
    conn.commit()
    cursor.close()
    conn.close()
    return jsonify({
        "message": "✅ Patient registered successfully!",
        "patient_name": data["full_name"]
    })

@patient_bp.route('/referral-summary', methods=['GET'])
def referral_summary():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT referred_by, COUNT(*) AS count
        FROM patients
        GROUP BY referred_by
        ORDER BY count DESC
    """)
    result = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(result)

# Keep only one version of get_all_patients
@patient_bp.route('/all', methods=['GET'])
def get_all_patients():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM patients ORDER BY patient_id DESC")
    patients = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(patients)

# Rename this route to avoid conflict, if you still need it
@patient_bp.route('/names', methods=['GET'])
def get_patient_names():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT patient_id, full_name FROM patients ORDER BY full_name ASC")
    patients = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(patients)

@patient_bp.route('/update/<int:patient_id>', methods=['PUT'])
def update_patient(patient_id):
    data = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE patients
        SET full_name=%s, gender=%s, mobile=%s, email=%s, age=%s,
            weight=%s, city=%s, pincode=%s, referred_by=%s
        WHERE patient_id=%s
    """, (
        data['full_name'],
        data['gender'],
        data['mobile'],
        data['email'],
        data['age'],
        data['weight'],
        data['city'],
        data['pincode'],
        data['referred_by'],
        patient_id
    ))
    conn.commit()
    cursor.close()
    conn.close()
    return jsonify({"message": "✏️ Patient updated successfully."})
