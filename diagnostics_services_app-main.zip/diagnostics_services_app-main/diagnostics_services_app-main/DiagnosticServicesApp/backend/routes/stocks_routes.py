from flask import Blueprint, jsonify
from backend.db import get_db_connection

stocks_bp = Blueprint('stocks', __name__)

@stocks_bp.route('/stocks/all', methods=['GET'])
def get_stocks():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT *, (quantity * unit_price) AS total_value FROM stocks")
    stocks = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(stocks)
from flask import Blueprint, jsonify
from backend.db import get_db_connection

stocks_bp = Blueprint('stocks', __name__)

@stocks_bp.route('/api/stocks', methods=['GET'])
def get_stocks():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT *, quantity * unit_price AS total_value FROM stocks")
    stocks = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(stocks)
