from flask import Blueprint, request, jsonify
from backend.db import get_db_connection

test_bp = Blueprint('test', __name__)

@test_bp.route('/add', methods=['POST'])
def add_test_result():
    data = request.json
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO test_reports (patient_name, test_name, result, notes)
        VALUES (%s, %s, %s, %s)
    """, (
        data['patient_name'],
        data['test_name'],
        data['result_text'],   # result_text from form -> result column in DB
        data['reported_by']    # reported_by from form -> notes column in DB
    ))

    conn.commit()
    cursor.close()
    conn.close()
    return jsonify({"message": "✅ Test result saved!"})

@test_bp.route('/all', methods=['GET'])
def get_all_tests():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM test_reports ORDER BY created_at DESC")
    results = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(results)
from flask import Blueprint, jsonify
from backend.db import get_db_connection

test_bp = Blueprint('test', __name__)

@test_bp.route('/all', methods=['GET'])
def get_all_tests():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT test_name, price FROM tests")
    tests = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(tests)
@test_bp.route('/save_batch', methods=['POST'])
def save_test_batch():
    data = request.get_json()
    patient_name = data['patient_name']
    reported_by = data['reported_by']
    tests = data['tests']  # List of { test_name, result }

    conn = get_db_connection()
    cursor = conn.cursor()

    for test in tests:
        cursor.execute("""
            INSERT INTO test_results (patient_name, test_name, result, notes, report_date)
            VALUES (%s, %s, %s, %s, CURDATE())
        """, (patient_name, test['test_name'], test['result'], f"Reported by {reported_by}"))

    conn.commit()
    cursor.close()
    conn.close()
    return jsonify({"message": "Test results saved successfully!"})
