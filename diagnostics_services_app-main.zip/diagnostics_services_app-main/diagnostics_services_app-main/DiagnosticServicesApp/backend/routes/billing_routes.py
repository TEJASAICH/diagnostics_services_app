from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
from backend.db import get_db_connection

billing_bp = Blueprint('billing', __name__)

# ✅ Route 1: Create a new bill
@billing_bp.route('/create', methods=['POST'])
@cross_origin()
def create_bill():
    data = request.json
    patient = data['patient']
    test = data['test']
    price = float(data['price'])
    discount = float(data['discount'])
    total = price - discount

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO billing (patient_name, test_name, test_price, discount, total_amount)
        VALUES (%s, %s, %s, %s, %s)
    """, (patient, test, price, discount, total))
    conn.commit()
    cursor.close()
    conn.close()

    return jsonify({"message": "Bill created successfully!", "total": total})


# ✅ Route 2: View all saved bills
@billing_bp.route('/all', methods=['GET'])
@cross_origin()
def get_all_bills():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM billing ORDER BY paid_date DESC")
    bills = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(bills)


# ✅ Route 3: Get tests for a specific patient (Corrected)
@billing_bp.route('/tests/<patient_name>', methods=['GET'])
@cross_origin()
def get_tests_for_patient(patient_name):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT t.test_name, t.price, bi.discount
        FROM bill_items bi
        JOIN bills b ON bi.bill_id = b.id
        JOIN tests t ON bi.test_id = t.test_id
        WHERE b.patient_name = %s
    """, (patient_name,))
    tests = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(tests)

